INSERT INTO contas VALUES (
null,
"Romarinho de Jubisclayton",
"romarinho@email.com",
"(11) 4002-8922",
"Sou Foda em Java",
"R$ 10"
);